For ECG dataset:

train.csv includes train data.
validation.csv includes validation data.
test.csv includes test data.
trainval.csv includes train and validation data.

For csv files, the first column is class label ("0" or "1") and column 2 to column 141 are 140 sequential measurements of ECG.